const express = require('express');
const router = express.Router();
const Autor = require('../models/autor.model');

// GET → listar todos los autores
router.get('/', async (req, res) => {
try {
    const autores = await Autor.findAll();
    res.json(autores);
} catch (error) {
    console.error('❌ Error al obtener autores:', error);
    res.status(500).json({ error: 'Error al obtener autores' });
}
});

// GET → obtener un autor por id
router.get('/:id', async (req, res) => {
try {
    const { id } = req.params;
    const autor = await Autor.findByPk(id);
    if (!autor) {
    return res.status(404).json({ error: 'Autor no encontrado' });
    }
    res.json(autor);
} catch (error) {
    console.error('❌ Error al obtener autor:', error);
    res.status(500).json({ error: 'Error al obtener autor' });
}
});

// POST → crear un nuevo autor
router.post('/', async (req, res) => {
try {
    const { nombre, estado } = req.body;
    if (!nombre || estado === undefined) {
    return res.status(400).json({ error: 'Faltan datos: nombre y estado' });
    }
    const nuevoAutor = await Autor.create({ nombre, estado });
    res.status(201).json(nuevoAutor);
} catch (error) {
    console.error('❌ Error al crear autor:', error);
    res.status(500).json({ error: 'Error al crear autor' });
}
});

// PUT → actualizar un autor por id
router.put('/:id', async (req, res) => {
try {
    const { id } = req.params;
    const { nombre, estado } = req.body;
    const autor = await Autor.findByPk(id);

    if (!autor) {
    return res.status(404).json({ error: 'Autor no encontrado' });
    }

    autor.nombre = nombre ?? autor.nombre;
    autor.estado = estado ?? autor.estado;
    await autor.save();

    res.json(autor);
} catch (error) {
    console.error('❌ Error al actualizar autor:', error);
    res.status(500).json({ error: 'Error al actualizar autor' });
}
});

// DELETE → eliminar un autor por id
router.delete('/:id', async (req, res) => {
try {
    const { id } = req.params;
    const autor = await Autor.findByPk(id);

    if (!autor) {
    return res.status(404).json({ error: 'Autor no encontrado' });
    }

    await autor.destroy();
    res.json({ mensaje: 'Autor eliminado correctamente' });
} catch (error) {
    console.error('❌ Error al eliminar autor:', error);
    res.status(500).json({ error: 'Error al eliminar autor' });
}
});

module.exports = router;
