const express = require('express');
const db = require('../db/db') //Ir a traer la base de datos

//Nueva variable
const router = express.Router()

//Definir las rutas

module.exports = router;