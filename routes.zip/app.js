const express = require('express');
require('dotenv').config();
const { Sequelize } = require('sequelize');
const cors = require("cors");

// Crear la conexión con MySQL
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST || 'localhost',
    dialect: 'mysql',
    port: process.env.DB_PORT || 3306,
    logging: false
  }
);

// Probar la conexión
sequelize.authenticate()
  .then(() => console.log('✅ Conexión a la base de datos '))
  .catch(err => console.error('❌ Error al conectar la base de datos', err));

// Importar rutas
const autorRoutes = require('./routes/autor.routes');

const app = express();
app.use(express.json());
app.use(cors());

// 👉 Ruta raíz que devuelve "ok"
app.get('/', (req, res) => {
  res.send('ok');
});

// 👉 Ruta de autores
app.use('/autor', autorRoutes);

// Sincronizar modelos y levantar servidor
sequelize.sync()
  .then(() => {
    const PORT = process.env.PORT || 3001;
    app.listen(PORT, () => {
      console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
      console.log(`🚀 Servidor corriendo en http://localhost:${PORT}/autor`);
    });
  })
  .catch(err => {
    console.error('Error al sincronizar modelos', err);
  });